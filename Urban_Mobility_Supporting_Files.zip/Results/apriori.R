
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) == 2L)
raw <- readLines(args[1], encoding="UTF-8")
frequencies <- table(raw)
tx <- strsplit(names(frequencies), ",", fixed=TRUE)
key <- function(items) paste(sort(items), collapse="|")
min_count <- ceiling(.02 * length(raw))
supports <- new.env(hash=TRUE, parent=emptyenv())
width <- 1L
repeat {
    counts <- new.env(hash=TRUE, parent=emptyenv())
    for (j in seq_along(tx)) {
        basket <- tx[[j]]
        if (length(basket) < width) next
        for (items in combn(basket, width, simplify=FALSE)) {
            if (width > 1L && !all(vapply(items, function(i)
                exists(key(setdiff(items,i)),supports,inherits=FALSE), logical(1)))) next
            k <- key(items)
            counts[[k]] <- if (is.null(counts[[k]])) frequencies[[j]] else counts[[k]]+frequencies[[j]]
        }
    }
    kept <- Filter(function(k) counts[[k]] >= min_count, ls(counts,all.names=TRUE))
    if (!length(kept)) break
    for (k in kept) supports[[k]] <- counts[[k]]/length(raw)
    width <- width+1L
}
rules <- list()
for (k in ls(supports,all.names=TRUE)) {
    items <- strsplit(k,"|",fixed=TRUE)[[1]]
    if (length(items)<2L) next
    for (outcome in grep("^(demand|delay)=",items,value=TRUE)) {
        lhs <- setdiff(items,outcome)
        support <- supports[[k]]
        confidence <- support/supports[[key(lhs)]]
        lift <- confidence/supports[[outcome]]
        if (confidence>=.35 && lift>1) rules[[length(rules)+1L]] <-
            data.frame(antecedent=paste(sort(lhs),collapse=" + "),consequent=outcome,
                       support=support,confidence=confidence,lift=lift)
    }
}
stopifnot(length(rules)>0)
rules <- do.call(rbind,rules)
write.csv(rules[order(-rules$lift,-rules$support),], args[2],row.names=FALSE)
