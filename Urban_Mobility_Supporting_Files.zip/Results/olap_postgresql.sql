-- Roll-up · day to month and season
SELECT t.season,t.month,COUNT(*) trips, ROUND(CAST(AVG(f.duration_min) AS NUMERIC),2) duration_min,
 ROUND(CAST(AVG(f.fare) AS NUMERIC),2) mean_fare, ROUND(CAST(100*AVG(f.high_delay) AS NUMERIC),2) delay_pct  FROM FACT_TRIP f JOIN DIM_TIME t USING(time_id)
 JOIN DIM_PICKUP_LOCATION p USING(pickup_id) JOIN DIM_WEATHER w USING(weather_id) 
     GROUP BY t.season,t.month UNION ALL SELECT t.season,'ALL', COUNT(*) trips, ROUND(CAST(AVG(f.duration_min) AS NUMERIC),2) duration_min,
 ROUND(CAST(AVG(f.fare) AS NUMERIC),2) mean_fare, ROUND(CAST(100*AVG(f.high_delay) AS NUMERIC),2) delay_pct  FROM FACT_TRIP f JOIN DIM_TIME t USING(time_id)
 JOIN DIM_PICKUP_LOCATION p USING(pickup_id) JOIN DIM_WEATHER w USING(weather_id) 
     GROUP BY t.season ORDER BY season,month;

-- Drill-down · Manhattan to zones and time periods
SELECT p.zone,t.period,COUNT(*) trips, ROUND(CAST(AVG(f.duration_min) AS NUMERIC),2) duration_min,
 ROUND(CAST(AVG(f.fare) AS NUMERIC),2) mean_fare, ROUND(CAST(100*AVG(f.high_delay) AS NUMERIC),2) delay_pct
      FROM FACT_TRIP f JOIN DIM_TIME t USING(time_id)
 JOIN DIM_PICKUP_LOCATION p USING(pickup_id) JOIN DIM_WEATHER w USING(weather_id)  WHERE p.borough='Manhattan' GROUP BY p.zone,t.period ORDER BY trips DESC LIMIT 12;

-- Slice · weekend
SELECT t.hour,COUNT(*) trips, ROUND(CAST(AVG(f.duration_min) AS NUMERIC),2) duration_min,
 ROUND(CAST(AVG(f.fare) AS NUMERIC),2) mean_fare, ROUND(CAST(100*AVG(f.high_delay) AS NUMERIC),2) delay_pct  FROM FACT_TRIP f JOIN DIM_TIME t USING(time_id)
 JOIN DIM_PICKUP_LOCATION p USING(pickup_id) JOIN DIM_WEATHER w USING(weather_id) 
     WHERE t.day_type='Weekend' GROUP BY t.hour ORDER BY t.hour;

-- Dice · two boroughs, peak hours, precipitation
SELECT p.borough,t.period,w.weather_category,COUNT(*) trips, ROUND(CAST(AVG(f.duration_min) AS NUMERIC),2) duration_min,
 ROUND(CAST(AVG(f.fare) AS NUMERIC),2) mean_fare, ROUND(CAST(100*AVG(f.high_delay) AS NUMERIC),2) delay_pct
      FROM FACT_TRIP f JOIN DIM_TIME t USING(time_id)
 JOIN DIM_PICKUP_LOCATION p USING(pickup_id) JOIN DIM_WEATHER w USING(weather_id)  WHERE p.borough IN ('Manhattan','Queens') AND t.rush_hour=1
     AND w.weather_category IN ('Snow','Heavy precipitation','Light precipitation')
     GROUP BY p.borough,t.period,w.weather_category ORDER BY trips DESC;

-- Pivot · borough by day type
SELECT p.borough,
     SUM(CASE WHEN t.day_type='Weekday' THEN 1 ELSE 0 END) weekday,
     SUM(CASE WHEN t.day_type='Weekend' THEN 1 ELSE 0 END) weekend  FROM FACT_TRIP f JOIN DIM_TIME t USING(time_id)
 JOIN DIM_PICKUP_LOCATION p USING(pickup_id) JOIN DIM_WEATHER w USING(weather_id)  GROUP BY p.borough;

-- Snowflake · zone to borough
SELECT b.borough, COUNT(*) trips FROM FACT_TRIP f
     JOIN DIM_ZONE_SNOWFLAKE z ON f.pickup_id=z.location_id JOIN DIM_BOROUGH b USING(borough_id)
     GROUP BY b.borough ORDER BY trips DESC;

-- Galaxy · trip activity by exposure hour
SELECT t.month,b.borough,COUNT(*) hours,
     ROUND(CAST(AVG(g.demand) AS NUMERIC),2) trips_per_hour FROM FACT_BOROUGH_HOUR g
     JOIN DIM_TIME t USING(time_id) JOIN DIM_BOROUGH b USING(borough_id)
     GROUP BY t.month,b.borough ORDER BY t.month,trips_per_hour DESC;
